﻿using System;
using BookstoreManagement.Store;


public class Program
{
    public static void Main(string[] args) 
    {
        BookStoreMenu menu = new BookStoreMenu();
        menu.InitMenu();

        
    }
}
